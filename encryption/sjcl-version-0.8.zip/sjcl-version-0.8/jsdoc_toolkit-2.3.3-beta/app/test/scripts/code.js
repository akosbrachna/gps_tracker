/**
	@class
 */
function thisiscode() {
}